#ifndef MYUTILS_H_INCLUDED
#define MYUTILS_H_INCLUDED

int factorial(int);
int isprime(int);
int ispallindrom(int);
int vsum(int,int,int,int,int);


#endif // MYUTILS_H_INCLUDED
